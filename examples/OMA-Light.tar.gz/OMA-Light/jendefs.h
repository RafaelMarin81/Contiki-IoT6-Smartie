/*****************************************************************************
 *
 * MODULE:              ALL MODULES
 *
 * COMPONENT:           $RCSfile: jendefs.h,v $
 *
 * VERSION:             $Name: RD_RELEASE_6thMay09 $
 *
 * REVISION:            $Revision: 1.3 $
 *
 * DATED:               $Date: 2008/10/22 12:09:43 $
 *
 * STATUS:              $State: Exp $
 *
 * AUTHOR:              Paul Chilton
 *
 * DESCRIPTION:
 * The JENNIC standard header file defining extensions to ANSI C standard
 * required by the Jennic C coding standard.
 *
 * LAST MODIFIED BY:    $Author: pjtw $
 *                      $Modtime: $
 *
 ****************************************************************************
 *
 * This software is owned by Jennic and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on Jennic products. You, and any third parties must reproduce
 * the copyright and warranty notice and any other legend of ownership on
 * each copy or partial copy of the software.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS". JENNIC MAKES NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE,
 * ACCURACY OR LACK OF NEGLIGENCE. JENNIC SHALL NOT, IN ANY CIRCUMSTANCES,
 * BE LIABLE FOR ANY DAMAGES, INCLUDING, BUT NOT LIMITED TO, SPECIAL,
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER.
 *
 * Copyright Jennic Ltd 2005, 2006. All rights reserved
 *
 ***************************************************************************/

#ifndef  JENDEFS_INCLUDED
#define  JENDEFS_INCLUDED


/****************************************************************************/
/***        Include Files                                                 ***/
/****************************************************************************/

#ifndef __KERNEL__
#include <stdarg.h>
#include <stdio.h>
#endif

#ifdef ECOS
#include <cyg/infra/cyg_type.h>
#endif

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/

/*--------------------------------------------------------------------------*/
/*          Compiler Constants for GCC compiler                             */
/*--------------------------------------------------------------------------*/

#ifdef __GCC__

/* The following 4 macros force the compiler to align the specified object  */
/* on a given byte boundary.                                                */
/* Example:                                                                 */
/*     int  iVar  ALIGN_(16);  Force iVar to be aligned on the next         */
/*                             16 byte boundary                             */

#define PACK      __attribute__ ((packed))        /* align to byte boundary  */
#define ALIGN_2   __attribute__ ((aligned (2)))   /* 16-bit boundary (2 byte)*/
#define ALIGN_4   __attribute__ ((aligned (4)))   /* 32-bit boundary (4 byte)*/
#define ALIGN_(x) __attribute__ (((aligned (x)))) /* arbitrary alignment     */

#endif

#ifdef WIN32

#define PACK

#endif

/*--------------------------------------------------------------------------*/
/*          Alignment masks                                                 */
/*--------------------------------------------------------------------------*/

#define ALIGNMENT_MASK_4_BYTE     ((uint32)0x00000003)
#define ALIGNMENT_MASK_16_BYTE    ((uint32)0x0000000F)

/* Test for alignment on an arbitrary byte boundary - TRUE if aligned */

#define IS_ALIGNED(addr, mask) (((((uint32)addr) & mask) ? FALSE : TRUE))

/*--------------------------------------------------------------------------*/
/*          Boolean Constants                                               */
/*--------------------------------------------------------------------------*/

#if !defined FALSE && !defined TRUE
#define TRUE            (1)   /* page 207 K+R 2nd Edition */
#define FALSE           (0)
#endif /* !defined FALSE && #if !defined TRUE */

/*     Note that WINDOWS.H also defines TRUE and FALSE                 */

/*--------------------------------------------------------------------------*/
/*          Null pointers                                                   */
/*--------------------------------------------------------------------------*/

/* NULL data pointer */
#if !defined NULL
#define NULL                    ( (void *) 0 )
#endif

/* NULL routine pointer */
#if !defined RNULL
#define RNULL                   ((void *) 0 ())
#endif

/*--------------------------------------------------------------------------*/
/*          Macros for setting/clearing bits efficiently                    */
/*--------------------------------------------------------------------------*/

#define U8_CLR_BITS( P, B )   (( *(uint8 *)P ) &= ~( B ))
#define U8_SET_BITS( P, B )   (( *(uint8 *)P ) |=  ( B ))
#define U16_CLR_BITS( P, B )  (( *(uint16 *)P ) &= ~( B ))
#define U16_SET_BITS( P, B )  (( *(uint16 *)P ) |=  ( B ))
#define U32_CLR_BITS( P, B )  (( *(uint32 *)P ) &= ~( B ))
#define U32_SET_BITS( P, B )  (( *(uint32 *)P ) |=  ( B ))

/*--------------------------------------------------------------------------*/
/*          Macros for obtaining maximum/minimum values                     */
/*--------------------------------------------------------------------------*/

#define MAX(A,B)                ( ( ( A ) > ( B ) ) ? ( A ) : ( B ) )
#define MIN(A,B)                ( ( ( A ) < ( B ) ) ? ( A ) : ( B ) )

/*--------------------------------------------------------------------------*/
/*          Number of bits in quantities                                    */
/*--------------------------------------------------------------------------*/

#define BITS_PER_U32            (32)
#define BITS_PER_U16            (16)
#define BITS_PER_U8             (8)
#define BITS_PER_NIBBLE         (4)

/*--------------------------------------------------------------------------*/
/*          Masking macros                                                  */
/*--------------------------------------------------------------------------*/

#define U8_LOW_NIBBLE_MASK      (0x0F)
#define U8_HIGH_NIBBLE_MASK     (0xF0)

#define U16_LOW_U8_MASK         (0x00FF)
#define U16_HIGH_U8_MASK        (0xFF00)

#define U32_LOWEST_U8_MASK      (0x000000FFL)
#define U32_LOW_U8_MASK         (0x0000FF00L)
#define U32_HIGH_U8_MASK        (0x00FF0000L)
#define U32_HIGHEST_U8_MASK     (0xFF000000L)

#define U32_LOWEST_U16_MASK     (0x0000FFFFL)
#define U32_HIGHEST_U16_MASK    (0xFFFF0000L)

/*--------------------------------------------------------------------------*/
/*          Macros for extracting uint8s from a uint16                      */
/*--------------------------------------------------------------------------*/

/* NOTE: U16_UPPER_U8 is only safe for an unsigned U16 as >> fills with the sign bit for signed variables */
#define U16_UPPER_U8( x )      ((uint8) ((x) >> BITS_PER_U8))
#define U16_LOWER_U8( x )      ((uint8) (((x) & U16_LOW_U8_MASK)))

/*--------------------------------------------------------------------------*/
/*          Macros for extracting uint8s from a uint32                      */
/*--------------------------------------------------------------------------*/

#define U32_HIGHEST_U8( x ) ((uint8)(((x) & U32_HIGHEST_U8_MASK) >> (BITS_PER_U16 + BITS_PER_U8)))

#define U32_HIGH_U8( x ) ((uint8)( ( ( x ) & U32_HIGH_U8_MASK ) >> BITS_PER_U16 ))

#define U32_LOW_U8( x ) ((uint8)( ( ( x ) & U32_LOW_U8_MASK ) >> BITS_PER_U8 ))

#define U32_LOWEST_U8( x ) ((uint8)( ( ( x ) & U32_LOWEST_U8_MASK ) ))

/*--------------------------------------------------------------------------*/
/*          Macros for extracting uint16s from a uint32                     */
/*--------------------------------------------------------------------------*/

#define U32_UPPER_U16( x )     ((uint16)( ( ( x ) & U32_HIGHEST_U16_MASK ) >> ( BITS_PER_U16 ) ))
#define U32_LOWER_U16( x )     ((uint16)( ( ( x ) & U32_LOWEST_U16_MASK ) ))

/*--------------------------------------------------------------------------*/
/*         Macros for assembling byte sequences into various word sizes     */
/*--------------------------------------------------------------------------*/

/* B0 - LSB, B3 - MSB */

#ifdef HOST_PROCESSOR_BIG_ENDIAN
/* BIG ENDIAN DEFINITIONS */
#define BYTE_ORDER_32(B3, B2, B1, B0)   ((B0) + (B1<<8) + (B2<<16) + (B3<<24))

#define BYTE_ORDER_24(B2, B1, B0)       ((B0) + (B1<<8) + (B2<<16))

#define BYTE_ORDER_16(B1, B0)           (uint16)(((B0) + (B1<<8)))

#define BYTE_ORDER_8(B0)                (B0)

#define BYTE_ORDER_4(B0)                (B0)
#else
/* LITTLE ENDIAN DEFINITIONS */
#define BYTE_ORDER_32(B3, B2, B1, B0)   ((B3) + (B2<<8) + (B1<<16) + (B0<<24))

#define BYTE_ORDER_24(B2, B1, B0)       ((B2) + (B1<<8) + (B0<<16))

#define BYTE_ORDER_16(B1, B0)           (uint16)(((B1) + (B0<<8)))

#define BYTE_ORDER_8(B0)                (B0)

#define BYTE_ORDER_4(B0)                (B0)
#endif

/*--------------------------------------------------------------------------*/
/*          Storage classes                                                 */
/*--------------------------------------------------------------------------*/

#if !defined PUBLIC
#define PUBLIC
#endif

#if !defined PRIVATE
#define PRIVATE static
#endif

#if !defined BANKED
#define BANKED
#endif

/*--------------------------------------------------------------------------*/
/* Useful macro for variables that are not currently referenced             */
/* Prevents compiler warnings and should not produce any code               */
/*--------------------------------------------------------------------------*/

#define VARIABLE_INTENTIONALLY_NOT_REFERENCED(x) (x=x);
#define CONST_POINTER_INTENTIONALLY_NOT_REFERENCED(p) (*p);
#define CONST_VARIABLE_INTENTIONALLY_NOT_REFERENCED(x) (x);

/*--------------------------------------------------------------------------*/
/* Offset of field m in a struct s                                          */
/*--------------------------------------------------------------------------*/

#if !defined(ECOS) && !defined(offsetof)
#define offsetof(type, tag)     ( (int)&( (type *)0 )->tag )
#endif

/*--------------------------------------------------------------------------*/
/*          Diagnostics                                                     */
/*--------------------------------------------------------------------------*/

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

    #ifndef __cplusplus /* microsoft specific */
        #ifndef bool /* Seems to need this in for certain M$ builds*/
            typedef int                     bool;     /* boolean type */
        #endif
    #endif

    typedef unsigned char           BOOL_T;     /* boolean type nothing to do with C++ */
    typedef unsigned char           bool_t;     /* boolean type nothing to do with C++ */

    typedef signed char             int8;
    typedef short                   int16;
    typedef long                    int32;
    typedef long long               int64;
    typedef unsigned char           uint8;
    typedef unsigned short          uint16;
    typedef unsigned long           uint32;
    typedef unsigned long long      uint64;

    typedef char *                  string;

    typedef volatile uint8          u8Register;
    typedef volatile uint16         u16Register;
    typedef volatile uint32         u32Register;

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

#endif  /* JENDEFS_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/


